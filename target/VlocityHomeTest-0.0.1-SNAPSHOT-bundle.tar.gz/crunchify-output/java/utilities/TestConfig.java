package utilities;

public class TestConfig {
	public static String server = "smtp.gmail.com";
	public static String from = "jamoon.mini@gmail.com";
	public static String password = "21454";
	public static String[] to = { "jamoon.mini@gmail.com" };
	public static String subject = "Extent Project Report";

	public static String messageBody = "TestMessage";
	public static String attachmentPath = "c:\\screenshot\\2017_10_3_14_49_9.jpg";
	public static String attachmentName = "error.jpg";
}
